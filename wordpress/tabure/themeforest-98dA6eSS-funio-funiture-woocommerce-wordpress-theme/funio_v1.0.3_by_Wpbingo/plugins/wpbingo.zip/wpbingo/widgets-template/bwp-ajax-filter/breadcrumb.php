<?php
	set_query_var('paged', false);
	funio_woocommerce_breadcrumb();
?>