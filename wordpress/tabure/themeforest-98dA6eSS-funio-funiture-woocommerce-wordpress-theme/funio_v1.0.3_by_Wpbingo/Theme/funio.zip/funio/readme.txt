=== Max ===
Contributors: Funio
Tags: woocommerce 2.6, clothing, electronic, fashion, fashion shop, wordpress 4.7, responsive, bootstrap 3, redux framework, rtl theme.
Requires at least: 4.7
Tested up to: 4.7
Stable tag: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Funio - Multipurpose Responsive WooCommerce Theme. Funio is the perfect theme for your shop or company website, or for all your client websites if you are an agency or freelancer. It got all the tools needs to create super fast responsive websites with amazing user experience. It got 8 predefined home layouts with 2 presets color for each layout and a revolutionary responsive page builder, so you can create anything without coding.
. Funio is perfectly and beautifully mix and match colors, banners, blocks... to give the whole layout a gorgeous look. First of all, the slideshow is the highlight point in homepage which is full for window and auto play with large images, title and description. You can create a beautiful & easy-to-use responsive slider with very interesting transition effects. Secondly,  Funio theme comes with many smart features, it allows you to control almost every part of the theme like: Vertical and Horizontal Megamenu Customer, Theme editor, Product Slider, Category Tab Slider, Category List Slider, Product Tabs Slider, Quick search categories, Filter by attributes and add to cart/wishlist/compare & Quickview vv.. In product page has a different product layout with On/Off Cloud Zoom, Product Tab Information, Product Review. It can help you customize, configure your theme very easily and flexible, you can manage your site as expected in very short time. Next, you can change this theme to Right to Left for Arabic, Hebrew in the title or in the description.Try demo now to experience this awesomeness and to explore more features in  Funio - Multipurpose Responsive WooCommerce Theme. We are sure that it will satisfy all your needs!

* 4 Unique Theme Layouts
* 100% Responsive WordPress Theme.
* Free Lifetime updates!
* WordPress 4.5+ Ready
* WPML Ready (.pot files included)
* Fully support RTL language!
* SEO Optimised
* Product Quick View, Product Compare and Ajax Wishlist
* WooCommerce 2.6+ Ready
* Visual Composer – $34 saved
* Revolution Slider – $19 saved
* Supports Chrome, Safari, Firefox, IE
* Child Theme included
* Demo content included! (quickstart package)

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0 =
* Released: January 15, 2017

Initial release.

